<?php

/*  Still obsolete it seems
class Boat {

    public  $boatnmbr = 0;
    public  $weight = 0;
    public  $engine =0;
    public  $length = 0;
    public  $rentperhour = 0;


    
    public function __construct($nmbr, $wght, $eng, $lngt, $rph){
        $this->boatnmbr = $nmbr;
        $this->weight = $wght;
        $this->engine = $eng;
        $this->length = $lngt;
        $this->rentperhour = $rph;

    }

    //Methods
        //input



}
 */
?>
